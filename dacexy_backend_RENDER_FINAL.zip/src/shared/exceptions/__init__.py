from fastapi import HTTPException, status


class AppError(HTTPException):
    pass


def not_found(detail="Not found"):
    raise HTTPException(status_code=404, detail=detail)


def unauthorized(detail="Unauthorized"):
    raise HTTPException(status_code=401, detail=detail)


def forbidden(detail="Forbidden"):
    raise HTTPException(status_code=403, detail=detail)


def bad_request(detail="Bad request"):
    raise HTTPException(status_code=400, detail=detail)


def conflict(detail="Conflict"):
    raise HTTPException(status_code=409, detail=detail)
